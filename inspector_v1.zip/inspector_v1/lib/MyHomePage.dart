import 'package:flutter/material.dart';
import './tabs/Camera_tab.dart';
import './tabs/Editor_tab.dart';

class MyHomePage extends StatefulWidget {
  final String title;
  MyHomePage({Key key, this.title}) : super(key: key);
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            title: Center(child: Text(widget.title)),
            bottom: TabBar(
              tabs: <Widget>[
                Tab(icon: Icon(Icons.camera_alt),),
                Tab(icon: Icon(Icons.image),)
              ],
            ),
          ),
          body: TabBarView(
            children: <Widget>[
              Camera_tab(),
              Editor_tab(),
            ],
          ),
        ),
      ),
    );
  }
}
