import 'package:flutter/material.dart';

class Editor_tab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text("Editor Tab"),
    );
  }
}
