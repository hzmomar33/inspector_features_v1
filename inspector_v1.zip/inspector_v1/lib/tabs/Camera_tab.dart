import 'dart:io';
import 'dart:async';
import 'package:camera_utils/camera_utils.dart';
import 'package:flutter/material.dart';

class Camera_tab extends StatefulWidget {
  @override
  _Camera_tabState createState() => _Camera_tabState();
}

class _Camera_tabState extends State<Camera_tab> {
  String _path = null;
  String _thumbPath = null;
  double _headerHeight = 320.0;
  final String _assetImagePath = 'assets/images/no_image.png';
  final String _assetLogoImagePath = 'assets/images/no_image.png';

  BuildContext context;
  @override
  Widget build(BuildContext context) {
    this.context = context;
    return Scaffold(
      body: Stack(
        children: <Widget>[
          _path != null ? _getImageFromFile() : _getImageFromAsset(),
          _getContentContainerLogo()
        ],
      ),
    );
  }

  Widget _getImageFromFile() {
    return Container(
      padding: EdgeInsets.only(bottom: 30),
      child: Container(
        width: double.infinity,
        height: _headerHeight,
        color: Colors.grey,
        child: Stack(
          children: <Widget>[
            Image.file(
              File(
                _path,
              ),
              fit: BoxFit.cover,
              width: double.infinity,
              height: _headerHeight,
            ),
            _buildPathWidget(),
          ],
        ),
      ),
    );
  }

  Widget _getImageFromAsset() {
    return Container(
      padding: EdgeInsets.only(bottom: 30.0),
      child: Container(
        width: double.infinity,
        height: _headerHeight,
        color: Colors.grey,
        child: Stack(
          children: <Widget>[
            Align(
              alignment: Alignment.center,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Image.asset(
                      _assetImagePath,
                      width: 48.0,
                      height: 32.0,
                    ),
                    Container(
                      margin: EdgeInsets.only(top: 8.0),
                      child: Text(
                        'No Preview Available',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16
                        ),
                      ),
                    )
                  ],
                ),
            ),
            _buildPathWidget(),
          ],
        ),
      ),
    );
  }

  Widget _buildPathWidget() {
    return _path != null ?
        Align(
          alignment: Alignment.bottomCenter,
          child: Container(
            width: double.infinity,
            height: 60.0,
            padding: EdgeInsets.all(20),
            color: Color.fromRGBO(00, 00, 00, 0.7),
            child: Text(
              'PATH: $_path',
              style: TextStyle(color: Colors.white),
            ),
          ),
        )
        : Container();
  }

  Widget _getContentContainerLogo() {
    return Container(
      margin: EdgeInsets.only(top: _headerHeight + 5.0),
      alignment: Alignment.center,
      child: Column(
        children: <Widget>[
          Container(
            color: Colors.red,
            padding: EdgeInsets.all(10),
            child: Row(
              mainAxisAlignment:  MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                InkWell(
                  onTap: _captureImage,
                  child: buildButtonControl(Icons.camera_alt, 'Capture Image'),
                ),
                InkWell(
                  onTap: _pickImage,
                  child: buildButtonControl(Icons.image, 'Pick Image'),
                ),

              ],
            ),
          ),
//          Center(
//            child: Image.asset(
//              _assetLogoImagePath,
//              width: 160.0,
//              height: 160,
//              fit: BoxFit.contain,
//            ),
//          )
        ],
      ),
    );
  }

  Widget buildButtonControl(IconData icon, String label){
    return Container(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Icon(icon, color: Colors.white,),
          Container(
            margin: const EdgeInsets.only(top: 8.0),
            child: Text(
              label,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w400,
                color: Colors.white
              ),
            ),
          )
        ],
      ),
    );
  }

  Future _captureImage() async {
    print('_captureImage');
    final path = await CameraUtils.captureImage;
    if(path != null){
      setState(() {
        _path = path;
      });
    }
  }

  Future _pickImage() async {
    final path = await CameraUtils.pickImage;
    if(path != null){
      setState(() {
        _path = path;
      });
    }
  }

}


