//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"
#import <camera_utils/CameraUtilsPlugin.h>

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [CameraUtilsPlugin registerWithRegistrar:[registry registrarForPlugin:@"CameraUtilsPlugin"]];
}

@end
